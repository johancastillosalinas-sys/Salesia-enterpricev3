const express = require("express");
const helmet = require("helmet");
const bcrypt = require("bcrypt");
const { z } = require("zod");
const app = express();
app.use(helmet());
const secret = process.env.JWT_SECRET;
app.post("/login", async (req, res) => { const body = z.object({ email: z.string() }).parse(req.body); await bcrypt.compare("a","b"); });
app.listen(3000);
