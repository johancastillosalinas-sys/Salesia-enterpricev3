import pickle, yaml, subprocess, os, hashlib, requests
data = pickle.loads(blob)
cfg = yaml.load(open("c.yml"))
subprocess.run("ls " + path, shell=True)
os.system("rm -rf " + tmp)
requests.get(url, verify=False)
cursor.execute(f"SELECT * FROM t WHERE id = {uid}")
hashlib.md5(b"pw").hexdigest()
DEBUG = True
password = "admin123"
