const express = require("express");
const https = require("https");
const { exec } = require("child_process");
const app = express();
const AWS_KEY = "AKIAABCDEFGHIJKLMNOP"; // fake
const stripe = "sk_live_aBcDeFgHiJkLmNoPqRsTuVwX";
const dbUrl = "postgres://admin:Zx9fK2mQ8vLp@db.internal:5432/shop";
const apiToken = "tok_8fK2mQ9xLpZ4vB7nR1sT";
app.get("/run", (req, res) => { exec("ls " + req.query.dir); res.send("ok"); });
app.get("/eval", (req, res) => { res.send(eval(req.query.code)); });
app.get("/user", (req, res) => { db.query("SELECT * FROM users WHERE id = " + req.query.id); });
app.get("/page", (req, res) => { document.getElementById("x").innerHTML = "<b>" + req.query.name + "</b>"; });
https.get("https://x.test", { rejectUnauthorized: false });
const token = Math.random().toString(36);
res.cookie("sid", token, { httpOnly: false, secure: false });
app.use(require("cors")());
const crypto = require("crypto"); crypto.createHash("md5").update("x");
localStorage.setItem("authToken", token);
